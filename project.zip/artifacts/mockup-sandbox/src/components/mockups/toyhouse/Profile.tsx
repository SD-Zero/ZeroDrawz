import { useState } from "react";

const css = `
@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=DM+Sans:wght@400;500;600&display=swap');
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  background: #05040e;
  color: #c8bfe0;
  font-size: 13px;
  line-height: 1.6;
  padding: 18px;
  min-height: 100vh;
  background-image:
    radial-gradient(circle, #ffffff14 1px, transparent 1px),
    radial-gradient(circle, #a78bfa08 1px, transparent 1px);
  background-size: 40px 40px, 80px 80px;
  background-position: 0 0, 20px 20px;
}

/* Outer row: sidebar + content side by side */
.page-layout {
  display: flex;
  align-items: flex-start;
  max-width: 1060px;
  margin: 0 auto;
  position: relative;
}

/* Scanlines overlay on body — purple, tighter spacing */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    transparent 0px,
    transparent 1px,
    rgba(120,0,220,0.14) 1px,
    rgba(120,0,220,0.14) 2px
  );
  pointer-events: none;
  z-index: 0;
}

/* ── VISUALIZER ── */
.visualizer {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 400px;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  padding: 0;
  z-index: -1;
  pointer-events: none;
  opacity: 0.72;
}

.viz-bar {
  width: 10px;
  border-radius: 0;
  margin-right: 2px;
  background: linear-gradient(to top, #9d30ff, #f472ffee);
  animation: viz-bounce var(--d, 1.2s) ease-in-out infinite alternate;
  animation-delay: var(--delay, 0s);
}

.viz-bar:last-child { margin-right: 0; }

@keyframes viz-bounce {
  0%   { height: 6px; }
  100% { height: var(--h, 80px); }
}

.wrap {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  position: relative;
}

.wrap > * { margin-bottom: 12px; }
.wrap > *:last-child { margin-bottom: 0; }

/* ── FLOATING OVERLAY IMAGES ── */
/* These sit on top of the grid, overlapping sections */
.float-sticker {
  position: absolute;
  z-index: 20;
  pointer-events: none;
}

.float-sticker img {
  border-radius: 8px;
  box-shadow: 0 0 24px #7c3aed55;
  display: block;
}

/* ── HEADER ── */
.header-card {
  border-radius: 12px;
  overflow: visible;
  border: 1px solid #3b1f6e;
  background: #0a0918;
  position: relative;
  box-shadow: 0 0 30px #7c3aed22, inset 0 0 40px #7c3aed0a;
}

.banner-img {
  width: 100%;
  height: 140px;
  object-fit: cover;
  display: block;
  border-radius: 11px 11px 0 0;
  filter: brightness(0.5) saturate(0.6);
}

.banner-tint {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 140px;
  background: linear-gradient(135deg, #7c3aed22 0%, transparent 50%, #05040e 100%);
  border-radius: 11px 11px 0 0;
  pointer-events: none;
}

/* Purple scanline effect over banner */
.banner-lines {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 140px;
  background: repeating-linear-gradient(
    0deg,
    transparent,
    transparent 3px,
    #7c3aed08 3px,
    #7c3aed08 4px
  );
  pointer-events: none;
  border-radius: 11px 11px 0 0;
}

.header-body {
  display: flex;
  align-items: flex-end;
  padding: 0 18px 16px;
  margin-top: -36px;
  position: relative;
  z-index: 2;
}

.avatar {
  width: 110px; height: 110px;
  border-radius: 10px;
  border: 3px solid #7c3aed;
  object-fit: cover;
  display: block;
  flex-shrink: 0;
  box-shadow: 0 0 20px #7c3aed77;
  margin-right: 16px;
}

.header-info { flex: 1; padding-bottom: 2px; }

.username {
  font-family: 'Rajdhani', sans-serif;
  font-size: 26px;
  font-weight: 700;
  color: #ede0ff;
  letter-spacing: 1px;
  text-shadow: 0 0 20px #a78bfa88;
}

.badge-row { display: flex; flex-wrap: wrap; margin-top: 6px; }

.badge {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 4px;
  border: 1px solid;
  display: inline-flex;
  align-items: center;
  line-height: 1.6;
  font-family: 'Rajdhani', sans-serif;
  letter-spacing: 0.5px;
  margin-right: 5px;
  margin-bottom: 5px;
}

.badge i { font-size: 9px; margin-right: 5px; }
.b-pur  { color: #c084fc; border-color: #c084fc44; background: #c084fc0d; }
.b-blue { color: #818cf8; border-color: #818cf844; background: #818cf80d; }
.b-pink { color: #e879f9; border-color: #e879f944; background: #e879f90d; }
.b-dim  { color: #7878a0; border-color: #7878a044; background: #7878a00d; }

/* Now Playing floated in header */
.header-player {
  flex-shrink: 0;
  background: #0a0918cc;
  border: 1px solid #3b1f6e;
  border-radius: 8px;
  padding: 8px 10px;
  width: 230px;
  backdrop-filter: blur(4px);
  align-self: flex-end;
  margin-bottom: 2px;
}

.hp-label {
  font-size: 8px;
  font-family: 'Rajdhani', sans-serif;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: #5a3a8a;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
}

.hp-label i { color: #7c3aed; font-size: 8px; margin-right: 5px; }

.hp-inner { display: flex; align-items: center; }

.hp-art {
  width: 48px; height: 48px;
  border-radius: 4px;
  flex-shrink: 0;
  border: 1px solid #3b1f6e;
  display: block;
  background: #12082a;
  object-fit: cover;
  margin-right: 8px;
}

.hp-info { flex: 1; min-width: 0; margin-right: 8px; }
.hp-title { font-size: 11px; font-weight: 600; color: #c8bfe0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.hp-artist { font-size: 9px; color: #5a3a8a; margin-top: 1px; }

.hp-bar { height: 2px; background: #1a1030; border-radius: 1px; margin-top: 6px; }
.hp-fill { height: 100%; width: 42%; background: linear-gradient(90deg, #7c3aed, #e879f9); border-radius: 1px; }


/* ── CAROUSEL ── */
.carousel-wrap {
  background: #0a0918;
  border: 1px solid #3b1f6e;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 0 20px #7c3aed11;
}

.carousel-head {
  padding: 8px 14px;
  border-bottom: 1px solid #1a0d38;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: #5a3a8a;
  display: flex;
  align-items: center;
  font-family: 'Rajdhani', sans-serif;
}

.carousel-head i { color: #7c3aed; margin-right: 7px; }

.carousel-scroll {
  display: flex;
  overflow-x: auto;
  padding: 12px 14px;
  scroll-snap-type: x mandatory;
  scrollbar-width: thin;
  scrollbar-color: #3b1f6e transparent;
}

.carousel-item {
  flex-shrink: 0;
  width: 140px;
  scroll-snap-align: start;
  border-radius: 7px;
  overflow: hidden;
  border: 1px solid #3b1f6e;
  cursor: pointer;
  position: relative;
  margin-right: 10px;
}

.carousel-item:last-child { margin-right: 0; }

.carousel-item img {
  width: 140px;
  height: 110px;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-drag: none;
  transition: filter 0.2s;
}

.carousel-item:hover img { filter: brightness(1.15); }

.carousel-item::after {
  content: '\f065';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  position: absolute;
  top: 6px; right: 7px;
  font-size: 10px;
  color: #ffffffaa;
  opacity: 0;
  transition: opacity 0.2s;
}

.carousel-item:hover::after { opacity: 1; }

.carousel-caption {
  padding: 5px 8px;
  font-size: 10px;
  font-weight: 600;
  color: #7878a0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background: #080714;
}

/* ── LIGHTBOX ── */
.lightbox {
  display: none;
  position: fixed;
  inset: 0;
  background: #000000e8;
  z-index: 1000;
  align-items: center;
  justify-content: center;
  padding: 20px;
  backdrop-filter: blur(6px);
}

.lightbox.open { display: flex; }

.lightbox-inner {
  position: relative;
  max-width: 90vw;
  max-height: 90vh;
  border: 1px solid #7c3aed66;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 0 60px #7c3aed66;
}

.lightbox-inner img {
  display: block;
  max-width: 90vw;
  max-height: 85vh;
  object-fit: contain;
}

.lightbox-close {
  position: absolute;
  top: 10px; right: 10px;
  width: 30px; height: 30px;
  background: #0a0918cc;
  border: 1px solid #7c3aed66;
  border-radius: 6px;
  color: #c084fc;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(4px);
}

.lightbox-close:hover { background: #7c3aed33; }

/* ── MAIN GRID ── */
.main {
  display: grid;
  grid-template-columns: 210px 1fr;
  align-items: start;
  position: relative;
}

.sidebar { display: flex; flex-direction: column; margin-right: 12px; }
.sidebar > * { margin-bottom: 10px; }
.sidebar > *:last-child { margin-bottom: 0; }

/* ── PANEL ── */
.panel {
  background: linear-gradient(135deg, rgba(0,0,0,0.82) 0%, rgba(0,0,0,0.82) 48%, rgba(13,6,32,0.82) 52%, rgba(13,6,32,0.82) 100%);
  border: 1px solid #3b1f6e;
  border-radius: 10px;
  overflow: visible;
  position: relative;
  box-shadow: 0 0 16px #7c3aed11;
}

.panel-head {
  padding: 8px 14px;
  border-bottom: 1px solid #1a0d38;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: #5a3a8a;
  display: flex;
  align-items: center;
  font-family: 'Rajdhani', sans-serif;
  border-radius: 10px 10px 0 0;
  background: #08061488;
}

.panel-head i { color: #7c3aed; font-size: 10px; margin-right: 7px; }

/* Subtle bg tint on panels */
.panel-bg {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0.06;
  filter: blur(3px) saturate(0.5);
  border-radius: 10px;
  pointer-events: none;
  z-index: 0;
}

.panel-body {
  padding: 12px 14px;
  position: relative;
  z-index: 1;
  border-radius: 0 0 10px 10px;
  overflow: hidden;
}

/* Image that OVERLAPS the panel top corner */
.panel-overlap-img {
  position: absolute;
  top: -14px;
  right: -10px;
  width: 60px;
  height: 60px;
  border-radius: 8px;
  object-fit: cover;
  box-shadow: 0 0 16px #7c3aed44;
  z-index: 10;
  transform: rotate(4deg);
  pointer-events: none;
}

/* ── INFO ROWS ── */
.info-rows { display: flex; flex-direction: column; }

.info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 0;
  border-bottom: 1px solid #1a0d3844;
}

.info-row:last-child { border-bottom: none; }

.i-key {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #3b2060;
  display: flex;
  align-items: center;
  flex-shrink: 0;
  font-family: 'Rajdhani', sans-serif;
}

.i-key i { color: #7c3aed; font-size: 9px; width: 12px; text-align: center; margin-right: 5px; }
.i-val { color: #9880c0; font-size: 12px; text-align: right; }

/* Wide accent image inside a panel */
.panel-img-strip {
  width: 100%;
  height: 44px;
  object-fit: cover;
  border-radius: 5px;
  opacity: 0.4;
  margin-bottom: 10px;
  display: block;
  filter: saturate(0.4) hue-rotate(240deg);
}

/* ── ART STATUS (all theme-colored) ── */
.status-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  margin-bottom: 9px;
}

.s-chip { margin: 0 3px 0 0; }
.s-chip:last-child { margin-right: 0; }

.s-chip {
  border-radius: 5px;
  padding: 7px 4px;
  text-align: center;
  border: 1px solid #3b1f6e;
  background: #0f0824;
}

.s-chip .s-lbl {
  font-size: 8px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #3b2060;
  margin-bottom: 3px;
  font-family: 'Rajdhani', sans-serif;
}

.s-chip .s-val {
  font-size: 11px;
  font-weight: 700;
  color: #9070c0;
  font-family: 'Rajdhani', sans-serif;
  letter-spacing: 0.5px;
}

.status-note { font-size: 11px; color: #3b2060; line-height: 1.6; font-style: italic; }

/* ── TH SIDEBAR ── */
.th-sidebar {
  width: 155px;
  flex-shrink: 0;
  position: sticky;
  top: 18px;
  align-self: stretch;
  background: linear-gradient(180deg, #070414 0%, #0d0620 100%);
  border: 1px solid #3b1f6e;
  border-radius: 10px;
  box-shadow: 0 0 20px #7c3aed22;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.th-sb-profile {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 14px 10px 10px;
  background: linear-gradient(to bottom, #12082a88, transparent);
}

.th-sb-profile > * { margin-bottom: 7px; }
.th-sb-profile > *:last-child { margin-bottom: 0; }

.th-sb-avatar {
  width: 78px;
  height: 78px;
  border-radius: 8px;
  object-fit: cover;
  border: 2px solid #7c3aed;
  box-shadow: 0 0 12px #7c3aed55;
  display: block;
}

.th-sb-username {
  font-family: 'Rajdhani', sans-serif;
  font-weight: 700;
  font-size: 13px;
  color: #c8bfe0;
  text-align: center;
  letter-spacing: 0.4px;
}

.th-sb-divider {
  height: 1px;
  background: linear-gradient(to right, transparent, #3b1f6e, transparent);
  margin: 3px 10px;
}

.th-sb-nav {
  display: flex;
  flex-direction: column;
  padding: 4px 0 8px;
}

.th-sb-link {
  display: flex;
  align-items: center;
  padding: 5px 14px;
  font-size: 11px;
  color: #7a6a9a;
  text-decoration: none;
  font-family: 'DM Sans', sans-serif;
  transition: color 0.15s, background 0.15s;
}

.th-sb-link:hover { color: #c084fc; background: #7c3aed11; }
.th-sb-link i { width: 13px; text-align: center; font-size: 10px; color: #7c3aed; flex-shrink: 0; margin-right: 8px; }

/* ── TABS ── */
.tab-nav { display: flex; flex-wrap: wrap; }

/* Tab pane show/hide */
.tab-pane { display: none; }
.tab-pane.active { display: block; }

.tab-btn {
  font-family: 'Rajdhani', sans-serif;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.8px;
  padding: 6px 15px;
  background: #0a0918;
  border: 1px solid #3b1f6e;
  border-bottom: none;
  border-radius: 8px 8px 0 0;
  color: #3b2060;
  cursor: pointer;
  display: flex;
  align-items: center;
  transition: color 0.15s;
  text-transform: uppercase;
  margin-right: 2px;
  margin-bottom: 2px;
}

.tab-btn i { font-size: 10px; margin-right: 6px; }

.tab-btn.active {
  border-color: #7c3aed88;
  color: #c084fc;
  background: #0f0824;
  box-shadow: 0 -4px 12px #7c3aed22;
}

.tab-body {
  background: #0a0918;
  border: 1px solid #7c3aed55;
  border-radius: 0 8px 8px 8px;
  padding: 18px;
  min-height: 280px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 0 30px #7c3aed11;
}

/* Atmospheric bg image inside tab */
.tab-bg {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0.07;
  filter: blur(4px) saturate(0.3) hue-rotate(260deg);
  pointer-events: none;
}

/* Image floating OVER tab content */
.tab-float-img {
  position: absolute;
  z-index: 5;
  pointer-events: none;
}

/* ── ABOUT ── */
.about-text {
  font-size: 13px;
  color: #9880c0;
  line-height: 1.85;
  position: relative;
  z-index: 1;
}

.about-text strong { color: #c084fc; font-weight: 600; }
.about-text em { color: #e879f9; font-style: italic; }

.divider { border: none; border-top: 1px solid #1a0d3866; margin: 14px 0; }

.notice {
  background: #0f0824;
  border: 1px solid #7c3aed44;
  border-radius: 7px;
  padding: 8px 12px;
  font-size: 11px;
  color: #9070c0;
  display: flex;
  align-items: flex-start;
  position: relative;
  z-index: 1;
}

.notice i { color: #a855f7; margin-top: 2px; flex-shrink: 0; margin-right: 8px; }

/* ── SECTION LABEL ── */
.sec-label {
  font-size: 9px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: #3b2060;
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  font-family: 'Rajdhani', sans-serif;
  position: relative;
  z-index: 1;
}

.sec-label::after { content: ''; flex: 1; height: 1px; background: linear-gradient(90deg, #3b1f6e, transparent); margin-left: 6px; }

/* ── OC CARDS ── */
.oc-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  position: relative;
  z-index: 1;
}

.oc-card { margin: 0 5px 10px; }

.oc-card {
  background: #0f0824;
  border: 1px solid #3b1f6e;
  border-radius: 10px;
  overflow: hidden;
  display: flex;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.oc-card:hover {
  border-color: #7c3aed88;
  box-shadow: 0 0 16px #7c3aed22;
}

.oc-portrait {
  width: 72px; flex-shrink: 0;
  background: #080714;
  overflow: hidden;
}

.oc-portrait img {
  width: 100%; height: 100%; min-height: 96px;
  object-fit: cover; display: block;
  filter: saturate(0.8);
}

.oc-info { padding: 10px 12px; flex: 1; min-width: 0; }

.oc-name {
  font-family: 'Rajdhani', sans-serif;
  font-size: 15px;
  font-weight: 700;
  color: #ddd0f8;
  letter-spacing: 0.5px;
}

.oc-species { font-size: 10px; color: #3b2060; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 2px; font-weight: 700; font-family: 'Rajdhani', sans-serif; }
.oc-desc { font-size: 11px; color: #6a5090; margin-top: 5px; line-height: 1.5; }
.oc-tags { display: flex; flex-wrap: wrap; margin-top: 7px; }
.oc-tag { margin-right: 4px; margin-bottom: 4px; }

.oc-tag {
  font-size: 9px;
  padding: 2px 7px;
  border-radius: 3px;
  background: #1a0d38;
  border: 1px solid #3b1f6e;
  color: #6a5090;
  font-family: 'Rajdhani', sans-serif;
  font-weight: 600;
  letter-spacing: 0.3px;
}

/* ── CHIPS ── */
.chip-cloud { display: flex; flex-wrap: wrap; position: relative; z-index: 1; }

.chip {
  font-size: 11px;
  padding: 4px 11px;
  border-radius: 4px;
  background: #0f0824;
  border: 1px solid #3b1f6e;
  color: #6a5090;
  display: flex;
  align-items: center;
  font-family: 'Rajdhani', sans-serif;
  font-weight: 600;
  letter-spacing: 0.3px;
  margin-right: 6px;
  margin-bottom: 6px;
}

.chip i { font-size: 10px; margin-right: 6px; }
.chip-pur  { border-color: #7c3aed44; color: #c084fc; background: #7c3aed0d; }
.chip-pink { border-color: #e879f944; color: #e879f9; background: #e879f90d; }
.chip-blue { border-color: #818cf844; color: #818cf8; background: #818cf80d; }

/* ── INTERESTS: mosaic ── */
.interest-mosaic {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  margin-bottom: 14px;
  border-radius: 6px;
  overflow: hidden;
  position: relative;
  z-index: 1;
  border: 1px solid #3b1f6e;
}

.mosaic-img {
  width: 100%;
  aspect-ratio: 1;
  object-fit: cover;
  display: block;
  transition: opacity 0.2s;
}

.mosaic-img:hover { opacity: 0.85; }

/* ── LINKS ── */
.link-grid { display: grid; grid-template-columns: 1fr 1fr; position: relative; z-index: 1; }

.link-card {
  display: flex;
  align-items: center;
  background: #0f0824;
  border: 1px solid #3b1f6e;
  border-radius: 6px;
  padding: 10px 12px;
  text-decoration: none;
  color: #6a5090;
  transition: border-color 0.15s, box-shadow 0.15s;
  margin: 0 4px 8px 4px;
}

.link-card:hover {
  border-color: #7c3aed88;
  box-shadow: 0 0 12px #7c3aed22;
  color: #c084fc;
}

.link-icon {
  width: 32px; height: 32px;
  border-radius: 5px;
  background: #1a0d38;
  border: 1px solid #3b1f6e;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #7c3aed;
  font-size: 14px;
  flex-shrink: 0;
  margin-right: 12px;
}

.link-label { font-weight: 700; font-size: 12px; color: #b0a0d8; font-family: 'Rajdhani', sans-serif; letter-spacing: 0.5px; }
.link-handle { font-size: 10px; color: #3b2060; margin-top: 1px; }
`;

const TABS = [
  { id: "about",     icon: "fa-solid fa-feather-pointed", label: "About" },
  { id: "ocs",       icon: "fa-solid fa-star",            label: "OCs" },
  { id: "interests", icon: "fa-solid fa-heart",           label: "Interests" },
  { id: "links",     icon: "fa-solid fa-link",            label: "Links" },
] as const;

type TabId = typeof TABS[number]["id"];

function tabContent(tab: TabId) {
  if (tab === "about") return `
    <div class="tab-bg" style="background-image:url('https://picsum.photos/seed/spbg1/800/400')"></div>
    <!-- Floating image over the corner — replace with MD logo or art -->
    <img class="tab-float-img" src="https://picsum.photos/seed/fl1/120/120"
      style="top:-18px;right:-16px;width:90px;height:90px;border-radius:50%;border:2px solid #7c3aed66;opacity:0.7;transform:rotate(-6deg);box-shadow:0 0 20px #7c3aed55;"
      alt="decorative">
    <p class="sec-label">about</p>
    <p class="about-text">
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore.
      <strong>Highlighted text goes here</strong> for emphasis. Ut enim ad minim veniam quis nostrud exercitation.
      <em>Italic accent text</em> for emphasis.<br><br>
      Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
    </p>
    <hr class="divider">
    <p class="sec-label">current obsessions</p>
    <div class="chip-cloud" style="margin-bottom:14px">
      <span class="chip chip-pur"><i class="fa-solid fa-fire"></i> Obsession One</span>
      <span class="chip chip-pink"><i class="fa-solid fa-fire"></i> Obsession Two</span>
      <span class="chip chip-blue"><i class="fa-solid fa-fire"></i> Obsession Three</span>
    </div>
    <div class="notice">
      <i class="fa-solid fa-triangle-exclamation"></i>
      Note or warning placeholder — lorem ipsum short notice here.
    </div>
  `;

  if (tab === "ocs") return `
    <div class="tab-bg" style="background-image:url('https://picsum.photos/seed/spbg2/800/400')"></div>
    <!-- Floating sticker image over grid corner -->
    <img class="tab-float-img" src="https://picsum.photos/seed/fl2/100/150"
      style="bottom:-20px;right:-14px;width:70px;height:100px;border-radius:6px;border:2px solid #7c3aed55;opacity:0.6;transform:rotate(5deg);box-shadow:0 0 16px #7c3aed44;"
      alt="decorative">
    <p class="sec-label">favorite characters</p>
    <div class="oc-grid">
      ${[64,65,66,67].map((seed, i) => `
        <div class="oc-card">
          <div class="oc-portrait">
            <img src="https://picsum.photos/seed/${seed}/150/200" alt="OC portrait" loading="lazy">
          </div>
          <div class="oc-info">
            <div class="oc-name">Character Name</div>
            <div class="oc-species">Species / Type</div>
            <div class="oc-desc">Short blurb about this character.</div>
            <div class="oc-tags">
              <span class="oc-tag">tag</span>
              <span class="oc-tag">tag</span>
              ${i % 2 === 0 ? '<span class="oc-tag">tag</span>' : ''}
            </div>
          </div>
        </div>
      `).join("")}
    </div>
  `;

  if (tab === "interests") return `
    <div class="tab-bg" style="background-image:url('https://picsum.photos/seed/spbg3/800/400')"></div>
    <div class="interest-mosaic">
      ${[71,72,73,74,75].map(s => `<img class="mosaic-img" src="https://picsum.photos/seed/${s}/80/80" alt="" loading="lazy">`).join("")}
    </div>
    <p class="sec-label">general interests</p>
    <div class="chip-cloud" style="margin-bottom:14px">
      <span class="chip"><i class="fa-solid fa-paw"></i> Interest One</span>
      <span class="chip"><i class="fa-solid fa-leaf"></i> Interest Two</span>
      <span class="chip"><i class="fa-solid fa-wand-magic-sparkles"></i> Interest Three</span>
      <span class="chip"><i class="fa-solid fa-music"></i> Interest Four</span>
      <span class="chip"><i class="fa-solid fa-paintbrush"></i> Interest Five</span>
      <span class="chip"><i class="fa-solid fa-book"></i> Interest Six</span>
    </div>
    <p class="sec-label">fandoms</p>
    <div class="chip-cloud" style="margin-bottom:14px">
      <span class="chip chip-pur">Fandom One</span>
      <span class="chip chip-pur">Fandom Two</span>
      <span class="chip chip-pur">Fandom Three</span>
      <span class="chip chip-blue">Fandom Four</span>
    </div>
    <p class="sec-label">favorite media</p>
    <div class="chip-cloud">
      <span class="chip chip-pink"><i class="fa-solid fa-gamepad"></i> Fave Game</span>
      <span class="chip chip-pink"><i class="fa-solid fa-tv"></i> Fave Show</span>
      <span class="chip chip-pink"><i class="fa-solid fa-book-open"></i> Fave Book</span>
      <span class="chip chip-pink"><i class="fa-solid fa-film"></i> Fave Film</span>
    </div>
  `;

  if (tab === "links") return `
    <div class="tab-bg" style="background-image:url('https://picsum.photos/seed/spbg4/800/400')"></div>
    <div class="link-grid">
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-brands fa-twitter"></i></div><div><div class="link-label">Twitter / X</div><div class="link-handle">@handle</div></div></a>
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-brands fa-deviantart"></i></div><div><div class="link-label">DeviantArt</div><div class="link-handle">@handle</div></div></a>
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-brands fa-instagram"></i></div><div><div class="link-label">Instagram</div><div class="link-handle">@handle</div></div></a>
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-brands fa-tumblr"></i></div><div><div class="link-label">Tumblr</div><div class="link-handle">@handle</div></div></a>
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-brands fa-discord"></i></div><div><div class="link-label">Discord</div><div class="link-handle">username</div></div></a>
      <a class="link-card" href="#"><div class="link-icon"><i class="fa-solid fa-link"></i></div><div><div class="link-label">Other Site</div><div class="link-handle">handle</div></div></a>
    </div>
  `;

  return "";
}

export function Profile() {
  const [view, setView] = useState<"preview" | "html" | "css">("preview");

  const BANNER = "https://picsum.photos/seed/spbanner1/900/200";
  const AVATAR  = "https://picsum.photos/seed/avatar7/160/160";
  const ALBUM   = "https://picsum.photos/seed/album1/80/80";

  const carousel = [10,20,30,40,50,60,80];

  const bodyHtml = `
<div class="page-layout">

  <!-- TH SIDEBAR (next to content, not over it) -->
  <div class="th-sidebar">
    <div class="th-sb-profile">
      <img class="th-sb-avatar" src="${AVATAR}" alt="Avatar">
      <div class="th-sb-username">Username</div>
    </div>
    <div class="th-sb-divider"></div>
    <nav class="th-sb-nav">
      <a class="th-sb-link" href="#"><i class="fa-solid fa-newspaper"></i> Bulletins</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-dragon"></i> Characters</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-link"></i> Links</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-globe"></i> Worlds</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-heart"></i> Favorites</a>
      <div class="th-sb-divider"></div>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-palette"></i> Designs</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-paintbrush"></i> Art</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-book"></i> Library</a>
      <div class="th-sb-divider"></div>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-comments"></i> Comments</a>
      <a class="th-sb-link" href="#"><i class="fa-solid fa-chart-bar"></i> Stats</a>
    </nav>
  </div>

  <!-- MAIN CONTENT -->
  <div class="wrap">

  <!-- VISUALIZER -->
  <div class="visualizer">
    ${Array.from({length: 80}, (_, i) => {
      const h = 40 + Math.floor(Math.abs(Math.sin(i * 0.6 + 1)) * 320);
      const d = (0.6 + Math.abs(Math.sin(i * 1.3)) * 1.4).toFixed(2);
      const delay = (Math.random() * 2).toFixed(2);
      return `<div class="viz-bar" style="--h:${h}px;--d:${d}s;--delay:${delay}s"></div>`;
    }).join("")}
  </div>

  <!-- LIGHTBOX -->
  <div class="lightbox" id="lightbox" onclick="if(event.target===this)this.classList.remove('open')">
    <div class="lightbox-inner">
      <img id="lightbox-img" src="" alt="Full image">
      <button class="lightbox-close" onclick="document.getElementById('lightbox').classList.remove('open')">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
  </div>

  <!-- Floating sticker overlapping header + carousel junction -->
  <div class="float-sticker" style="top:160px;right:24px;z-index:20">
    <img src="https://picsum.photos/seed/sticker1/100/130"
      style="width:80px;height:105px;transform:rotate(-8deg);opacity:0.85;"
      alt="decorative sticker">
  </div>

  <!-- HEADER -->
  <div class="header-card">
    <img class="banner-img" src="${BANNER}" alt="Banner">
    <div class="banner-tint"></div>
    <div class="banner-lines"></div>

    <!-- YouTube IFrame API -->
    <script src="https://www.youtube.com/iframe_api"></script>
    <div id="yt-player" style="position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;opacity:0;"></div>
    <script>
      var __ytPlayer, __ytPlaying = false;
      function onYouTubeIframeAPIReady() {
        __ytPlayer = new YT.Player('yt-player', {
          videoId: 'pACpFti2BtQ',
          playerVars: { autoplay: 0, controls: 0 },
          events: {
            onStateChange: function(e) {
              __ytPlaying = e.data === YT.PlayerState.PLAYING;
              var btn = document.getElementById('play-btn');
              if (btn) btn.innerHTML = __ytPlaying
                ? '<i class="fa-solid fa-pause"></i>'
                : '<i class="fa-solid fa-play"></i>';
            }
          }
        });
        setInterval(function() {
          if (__ytPlayer && __ytPlaying) {
            var dur = __ytPlayer.getDuration();
            var cur = __ytPlayer.getCurrentTime();
            if (dur > 0) {
              var fill = document.getElementById('hp-fill');
              if (fill) fill.style.width = ((cur / dur) * 100) + '%';
            }
          }
        }, 1000);
      }
    </script>

    <!-- Now Playing floated inside banner -->
    <div style="position:absolute;top:12px;right:14px;z-index:5">
      <div class="header-player">
        <div class="hp-label"><i class="fa-solid fa-music"></i> now playing</div>
        <div class="hp-inner">
          <img class="hp-art" src="${ALBUM}" alt="Album art">
          <div class="hp-info">
            <div class="hp-title">Break the Cycle</div>
            <div class="hp-artist">Andromida</div>
            <div class="hp-bar"><div class="hp-fill" id="hp-fill" style="width:0%"></div></div>
          </div>
          <button id="play-btn" onclick="(function(){
            if (!__ytPlayer) return;
            if (__ytPlaying) { __ytPlayer.pauseVideo(); } else { __ytPlayer.playVideo(); }
          })()" style="background:none;border:1px solid #7c3aed66;border-radius:4px;color:#a78bfa;width:24px;height:24px;display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;font-size:10px;padding:0;">
            <i class="fa-solid fa-play"></i>
          </button>
        </div>
      </div>
    </div>

    <div class="header-body">
      <img class="avatar" src="${AVATAR}" alt="Avatar">
      <div class="header-info">
        <div class="username">Username</div>
        <div class="badge-row">
          <span class="badge b-pur"><i class="fa-solid fa-venus-mars"></i> pronouns</span>
          <span class="badge b-blue"><i class="fa-solid fa-clock"></i> timezone</span>
          <span class="badge b-pink"><i class="fa-solid fa-star"></i> badge</span>
          <span class="badge b-dim"><i class="fa-solid fa-tag"></i> badge</span>
        </div>
      </div>
    </div>

  </div>

  <!-- ART CAROUSEL -->
  <div class="carousel-wrap">
    <div class="carousel-head"><i class="fa-solid fa-images"></i> art showcase — click to view</div>
    <div class="carousel-scroll">
      ${carousel.map(seed => `
        <div class="carousel-item" onclick="
          var lb=document.getElementById('lightbox');
          document.getElementById('lightbox-img').src='https://picsum.photos/seed/${seed}/800/600';
          lb.classList.add('open');
        ">
          <img src="https://picsum.photos/seed/${seed}/280/220" alt="Art piece" loading="lazy">
        </div>
      `).join("")}
    </div>
  </div>

  <!-- MAIN -->
  <div class="main">

    <!-- SIDEBAR -->
    <div class="sidebar">

      <div class="panel">
        <div class="panel-bg" style="background-image:url('https://picsum.photos/seed/sbg1/300/400')"></div>
        <img class="panel-overlap-img" src="https://picsum.photos/seed/qinfo1/120/120" alt="" style="transform:rotate(6deg)">
        <div class="panel-head"><i class="fa-solid fa-id-card"></i> quick info</div>
        <div class="panel-body">
          <div class="info-rows">
            <div class="info-row">
              <span class="i-key"><i class="fa-solid fa-star-and-crescent"></i> sign</span>
              <span class="i-val">—</span>
            </div>
            <div class="info-row">
              <span class="i-key"><i class="fa-solid fa-brain"></i> mbti</span>
              <span class="i-val">—</span>
            </div>
            <div class="info-row">
              <span class="i-key"><i class="fa-solid fa-earth-americas"></i> country</span>
              <span class="i-val">—</span>
            </div>
            <div class="info-row">
              <span class="i-key"><i class="fa-solid fa-palette"></i> software</span>
              <span class="i-val">—</span>
            </div>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-bg" style="background-image:url('https://picsum.photos/seed/sbg3/300/300')"></div>
        <img class="panel-overlap-img" src="https://picsum.photos/seed/ov2/120/120" alt="" style="transform:rotate(-5deg)">
        <div class="panel-head"><i class="fa-solid fa-pen-nib"></i> art status</div>
        <div class="panel-body">
          <div class="status-grid">
            <div class="s-chip"><div class="s-lbl">comm</div><div class="s-val">OPEN</div></div>
            <div class="s-chip"><div class="s-lbl">trades</div><div class="s-val">CLOSED</div></div>
            <div class="s-chip"><div class="s-lbl">reqs</div><div class="s-val">ASK</div></div>
          </div>
          <p class="status-note">Placeholder note about commissions or trades here.</p>
        </div>
      </div>

    </div>

    <!-- TABS -->
    <div>
      <div class="tab-nav">
        ${TABS.map(t => `
          <button class="tab-btn${t.id === "about" ? " active" : ""}" data-tab="${t.id}"
            onclick="(function(id){
              document.querySelectorAll('.tab-pane').forEach(function(el){el.classList.remove('active');});
              document.querySelectorAll('.tab-btn').forEach(function(el){el.classList.remove('active');});
              document.getElementById('tab-'+id).classList.add('active');
              document.querySelector('[data-tab=\\''+id+'\\']').classList.add('active');
            })('${t.id}'); return false;">
            <i class="${t.icon}"></i> ${t.label}
          </button>
        `).join("")}
      </div>
      <div class="tab-body">
        ${TABS.map(t => `<div id="tab-${t.id}" class="tab-pane${t.id === "about" ? " active" : ""}">${tabContent(t.id as TabId)}</div>`).join("")}
      </div>
    </div>

  </div>
  </div>
</div>
`;

  const srcDoc = `<!DOCTYPE html><html><head>
<meta charset="UTF-8">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>${css}</style>
</head><body>${bodyHtml}</body></html>`;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#05040e" }}>
      <div style={{
        display: "flex", alignItems: "center", gap: "5px",
        padding: "8px 12px", background: "#08061a", borderBottom: "1px solid #2a1a4a", flexShrink: 0,
      }}>
        {(["preview", "html", "css"] as const).map(v => (
          <button key={v} onClick={() => setView(v)} style={{
            fontFamily: "'DM Sans',sans-serif", fontSize: "11px", fontWeight: 600,
            padding: "4px 12px", border: "1px solid", borderRadius: "6px", cursor: "pointer",
            background: view === v ? "#1a0d38" : "transparent",
            borderColor: view === v ? "#7c3aed66" : "#2a1a4a",
            color: view === v ? "#c084fc" : "#3b2060",
          }}>{v.toUpperCase()}</button>
        ))}
        <div style={{ flex: 1 }} />
        {view !== "preview" && (
          <button onClick={() => navigator.clipboard.writeText(view === "css" ? css.trim() : bodyHtml.trim())} style={{
            fontFamily: "'DM Sans',sans-serif", fontSize: "11px", fontWeight: 600,
            padding: "4px 14px", background: "#7c3aed22", border: "1px solid #7c3aed66",
            borderRadius: "6px", color: "#c084fc", cursor: "pointer",
          }}>Copy {view.toUpperCase()}</button>
        )}
      </div>

      {view === "preview" ? (
        <iframe srcDoc={srcDoc} style={{ flex: 1, border: "none", width: "100%" }} title="Profile Preview" />
      ) : (
        <div style={{ flex: 1, overflow: "auto", background: "#05040e", padding: "16px" }}>
          <pre style={{ color: "#6a5090", fontFamily: "monospace", fontSize: "11px", lineHeight: "1.7", whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
            {view === "css" ? css.trim() : bodyHtml.trim()}
          </pre>
        </div>
      )}
    </div>
  );
}
